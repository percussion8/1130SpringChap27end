package com.green.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.green.domain.Criteria;
import com.green.domain.ReplyPageDTO;
import com.green.domain.ReplyVO;
import com.green.mapper.BoardMapper;
import com.green.mapper.ReplyMapper;

import lombok.Setter;

@Service
public class ReplyServiceImpl implements ReplyService{
	@Setter(onMethod_=@Autowired)
	private ReplyMapper mapper;
	
	@Setter(onMethod_=@Autowired)
	private BoardMapper boardMapper;

	@Transactional
	@Override
	public int register(ReplyVO reply) {
		boardMapper.updateReplyCnt(reply.getBno(), 1);
		return mapper.insert(reply);
	}

	@Override
	public ReplyVO getR(Long rno) {
		return mapper.read(rno);
	}

	@Override
	public int modify(ReplyVO reply) {
		return mapper.update(reply);
	}

	@Override
	public List<ReplyVO> getList(Criteria crit, Long bno) {
		return mapper.getListWithPaging(crit, bno);
	}

	@Transactional
	@Override
	public int remove(Long rno) {
		ReplyVO reply = mapper.read(rno);
		boardMapper.updateReplyCnt(reply.getBno(), -1);
		return mapper.delete(rno);
	}

	@Override
	public ReplyPageDTO getListPage(Criteria crit, Long bno) {
		int count = mapper.getCountbyBno(bno);
		List<ReplyVO> list = mapper.getListWithPaging(crit, bno);
		System.out.println("리플라이서비스에서 페이지로 조회시의 갯수" + count + "목록은" + list);
		return new ReplyPageDTO(count,list);
	}

}
